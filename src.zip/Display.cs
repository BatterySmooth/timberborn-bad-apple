using System.Diagnostics;
using System.Text.Json;

namespace TimberNet.Demo;

public class Display(string id, int width, int height)
{
  public readonly string Id = id;
  public readonly int Width = width;
  public readonly int Height = height;

  public async Task PixelSet(int x, int y, string color) => await TimberClient.PostAsync($"color/{Id}-{x}.{y}/{color}");
  public async Task PixelOff(int x, int y) => await TimberClient.PostAsync($"switch-off/{Id}-{x}.{y}");
  public async Task PixelOn(int x, int y) => await TimberClient.PostAsync($"switch-on/{Id}-{x}.{y}");
  
  public async Task ScreenOff(int maxParallelism = 100)
  {
    var pixels = GetAllPixels();
    await Parallel.ForEachAsync(pixels,
      new ParallelOptions { MaxDegreeOfParallelism = maxParallelism },
      async (pixel, ct) => await PixelOff(pixel.x, pixel.y));
  }

  public async Task ScreenOn(int maxParallelism = 100)
  {
    var pixels = GetAllPixels();
    await Parallel.ForEachAsync(pixels,
      new ParallelOptions { MaxDegreeOfParallelism = maxParallelism },
      async (pixel, ct) => await PixelOn(pixel.x, pixel.y));
  }

  private IEnumerable<(int x, int y)> GetAllPixels()
  {
    for (var x = 1; x <= Width; x++)
      for (var y = 1; y <= Height; y++)
        yield return (x, y);
  }
  
  
  const int TargetFps = 30;
  const double FrameDurationMs = 1000.0 / TargetFps;
  
  public async Task PlayFrames(string jsonFilePath, int maxParallelism = 500)
  {
    var json = await File.ReadAllTextAsync(jsonFilePath);
    var frames = JsonSerializer.Deserialize<List<string[][]>>(json);

    var stopwatch = Stopwatch.StartNew();
    var totalFrames = frames.Count;

    await TimberClient.PostAsync("switch-on/audio");
    // http://localhost:8080/api/switch-on/audio

    var frameIndex = 0;
    while (frameIndex < totalFrames)
    {
      var elapsedMs = stopwatch.Elapsed.TotalMilliseconds;
      var expectedFrame = (int)(elapsedMs / FrameDurationMs);

      if (expectedFrame >= totalFrames)
        break;

      frameIndex = expectedFrame;
      var frame = frames[frameIndex];

      var pixels = GetAllPixels();

      await Parallel.ForEachAsync(pixels,
        new ParallelOptions { MaxDegreeOfParallelism = maxParallelism },
        async (pixel, ct) =>
        {
          var x = pixel.x - 1; // convert 1-based to 0-based index
          var y = (Height - pixel.y); // flip Y-axis

          var color = frame[x][y];
          await PixelSet(pixel.x, pixel.y, color);
        });

      // // Optional: tiny delay so CPU can breathe
      // await Task.Delay(1);
    }
  }
}