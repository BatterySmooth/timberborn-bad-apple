﻿namespace TimberNet.Demo;

class Program
{
  static async Task Main(string[] args)
  {
    var display = new Display("d1", 49, 28);
    await display.PlayFrames(@".\frames.json", 200);
  }
}