namespace TimberNet.Demo;

public static class TimberClient
{
  private static readonly HttpClient Client = new() { BaseAddress = new Uri("http://localhost:8080/api/") };

  public static async Task PostAsync(string endpoint)
  {
    try
    {
      var response = await Client.GetAsync(endpoint);
      if (!response.IsSuccessStatusCode)
        Console.WriteLine($"Post failed: {response.StatusCode}");
    }
    catch (Exception ex)
    {
      Console.WriteLine($"Post failed: {ex.Message}");
    }
  }
}